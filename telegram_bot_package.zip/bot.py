import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# قراءة التوكن من ملف خارجي
with open("token.txt") as f:
    TOKEN = f.read().strip()

bot = telebot.TeleBot(TOKEN)

students = []
registration_open = True
title = "📋 قائمة طالبات أكاديمية الرحمة 📋"

last_message_id = None
last_chat_id = None

bot.set_my_commands([
    telebot.types.BotCommand("/start", "بدء القائمة"),
    telebot.types.BotCommand("/stop", "إيقاف التسجيل مؤقتًا"),
    telebot.types.BotCommand("/stopdefinitely", "إيقاف التسجيل نهائيًا ومسح القائمة"),
    telebot.types.BotCommand("/edittitle", "تعديل عنوان القائمة")
])

def build_keyboard():
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(
        InlineKeyboardButton("📝 سجل اسمي", callback_data="register"),
        InlineKeyboardButton("❌ احذف اسمي", callback_data="unregister"),
        InlineKeyboardButton("🎧 مستمعة", callback_data="list_students")
    )
    return markup

def get_students_text():
    if not students:
        return "لا توجد أسماء مسجلة حالياً."
    return "\n".join([f"{i+1}. {name}" for i, name in enumerate(students)])

def is_admin(message):
    try:
        member = bot.get_chat_member(message.chat.id, message.from_user.id)
        return member.status in ['creator', 'administrator']
    except Exception:
        return False

def is_admin_by_id(chat_id, user_id):
    try:
        member = bot.get_chat_member(chat_id, user_id)
        return member.status in ['creator', 'administrator']
    except Exception:
        return False

def safe_send_message(chat_id, text, **kwargs):
    try:
        return bot.send_message(chat_id, text, **kwargs)
    except telebot.apihelper.ApiTelegramException as e:
        print(f"Failed to send message to {chat_id}: {e}")
        return None

def safe_edit_message_text(text, chat_id, message_id, **kwargs):
    try:
        bot.edit_message_text(text, chat_id=chat_id, message_id=message_id, **kwargs)
    except telebot.apihelper.ApiTelegramException as e:
        print(f"Failed to edit message {message_id} in chat {chat_id}: {e}")

@bot.message_handler(commands=['start'])
def handle_start(message):
    global last_message_id, last_chat_id
    sent = safe_send_message(
        message.chat.id,
        f"<b>{title}</b>\n\n{get_students_text()}",
        parse_mode='HTML',
        reply_markup=build_keyboard()
    )
    if sent:
        last_message_id = sent.message_id
        last_chat_id = message.chat.id

@bot.message_handler(commands=['stop'])
def handle_stop(message):
    global registration_open
    if not is_admin(message):
        safe_send_message(message.chat.id, "هذا الأمر للمشرفين فقط.")
        return
    registration_open = False
    safe_send_message(message.chat.id, "تم إيقاف التسجيل مؤقتًا ✅")

@bot.message_handler(commands=['stopdefinitely'])
def handle_stopdefinitely(message):
    global registration_open, students
    if not is_admin(message):
        safe_send_message(message.chat.id, "هذا الأمر للمشرفين فقط.")
        return
    registration_open = False
    students = []
    safe_send_message(message.chat.id, "تم حذف القائمة وإيقاف التسجيل نهائيًا ❌")
    update_main_list()

@bot.message_handler(commands=['edittitle'])
def handle_edittitle(message):
    if not is_admin(message):
        safe_send_message(message.chat.id, "هذا الأمر للمشرفين فقط.")
        return
    msg = safe_send_message(message.chat.id, "أرسل العنوان الجديد:")
    if msg:
        bot.register_next_step_handler(msg, lambda m: update_title(m, message.chat.id, message.from_user.id))

def update_title(message, chat_id, user_id):
    if not is_admin_by_id(chat_id, user_id):
        safe_send_message(chat_id, "عذرًا، فقط المشرفون يمكنهم تعديل العنوان.")
        return
    global title
    title = message.text
    safe_send_message(chat_id, f"تم تحديث العنوان إلى:\n<b>{title}</b>", parse_mode="HTML")
    update_main_list()

def update_main_list():
    global last_message_id, last_chat_id
    if last_message_id and last_chat_id:
        safe_edit_message_text(
            f"<b>{title}</b>\n\n{get_students_text()}",
            chat_id=last_chat_id,
            message_id=last_message_id,
            parse_mode='HTML',
            reply_markup=build_keyboard()
        )

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    global students

    user_name = call.from_user.first_name
    if call.from_user.last_name:
        user_name += " " + call.from_user.last_name

    if call.data == "register":
        if not registration_open:
            return bot.answer_callback_query(call.id, "❌ التسجيل غير متاح حالياً.")
        if user_name in students:
            return bot.answer_callback_query(call.id, "❗️ اسمك مسجل بالفعل.")
        students.append(user_name)
        update_main_list()
        bot.answer_callback_query(call.id, "✅ تم تسجيل اسمك.")

    elif call.data == "unregister":
        if user_name in students:
            students.remove(user_name)
            bot.answer_callback_query(call.id, "✅ تم حذف اسمك.")
        else:
            bot.answer_callback_query(call.id, "❌ اسمك غير موجود.")
        update_main_list()

    elif call.data == "list_students":
        bot.answer_callback_query(call.id)
        update_main_list()

print("✅ البوت يعمل الآن...")
bot.infinity_polling()
